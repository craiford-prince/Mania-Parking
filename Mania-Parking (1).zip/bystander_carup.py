import pygame, sys, time
from pygame.locals import *

B_CARUP = pygame.image.load('Objects/bystander_carup.png')

class bystander_carup(pygame.sprite.Sprite):
    def __init__(self, xground3 , yground3):

        super().__init__()

        self.x = xground3
        self.y = yground3

        self.image = B_CARUP

        self.rect = pygame.Rect(self.x, self.y, 25, 40)