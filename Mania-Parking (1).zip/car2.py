import pygame, sys, time
from pygame.locals import *


CAR2 = pygame.image.load('Objects/car2.png')

class car2(pygame.sprite.Sprite):
    def __init__(self, ground2):

        super().__init__()

        self.x = 580
        self.y = ground2

        self.image = CAR2
        self.rect = pygame.Rect(self.x, self.y, 88, 52)

    def left(self):
        self.rect.x = self.rect.x - 5
    def right(self):
        self.rect.x = self.rect.x + 5
